<?php
    require_once 'php/instalator.php';
?>