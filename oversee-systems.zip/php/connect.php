<?php

    $host = "--host--";
    $db_user = "--username--";
    $db_password = "--password--";
    $db_name = "--database--";

?>