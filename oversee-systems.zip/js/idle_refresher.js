$(document).ready(function(){
    
    $(document).idle({

    onIdle: function(){
        
        location.reload();

    }, idle: 120000});
    
});
